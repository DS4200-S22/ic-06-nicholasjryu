
// JS File for class demo 
// Ab Mosca 
// Last moditifed: 02.10.2022 


//########################################################################
// This is an external js file that I've added to my html 
//      it's added with the <script> tag. 
//########################################################################

//########################################################################
// Printing to the developer console 
//      How do we print values for debugging? 
//########################################################################

//########################################################################
// Variables 
//      There are three ways to declare variables in JS (var, const, let)
//      Types of vaiables are string, number, boolean 
//########################################################################

// var -- DON'T USE THIS! It's depricated. 

// const -- This is for constant (unchangeable) variables

// let -- This is for variables with values that can change 

// Variables can be strings like those above, or numbers, or boolean 

// JavaScript is loosely typed, that means it will not stop you from 
//  changing variable type with an assignment

//########################################################################
// Built in JS Functions  
//      Functions built into the language and from Libraries.  
//########################################################################

// console.log 

// typeof

// Math.random 

//########################################################################
// User defined JS Functions  
//      Functions you (the coder) define   
//########################################################################

// We define function with the key word function, name of the function
// parameters, and a body. 
// The function does not have to take parameters. 

// Note that the scope of myRand is only within printRoundedRand()
// In other words, this will cause an error. 
// console.log(myRand); 

// Call or invoke a user defined function with its name and parameters

// Functions usually return something

// Function with parameters

// Note the parameters 

//########################################################################
// Anonymous JS Functions  
//      We can also use functions we define but do not name
//      Because they do not have a name, we call them anonymous 
//      This will become more important when we start using D3  
//########################################################################

// Note the syntax -- the () at the end automatically invokes the function

// We can also write these functions with => notation 

// We will come back to anonymous function when we start D3

//########################################################################
// Interactivity with JS
//      We use JS to make our webpages interactive.
//      To do this we use functions that respond to "events" or things
//      we expect from the user like clicks, hovers, drags, etc.  
//########################################################################

// Update the text in button-div when the button is clicked 

// First, let's define a function 

// Next, we need to update our html so this function is called 
// when the button is clicked 

//########################################################################
// Big hint for your next homework
//      You will want to look into how to add Event Listeners to svg's
//      This will involve document.getElementById, and then using the 
//      function .addEventListener(event, func)
//########################################################################

// Resources: 
// https://developer.mozilla.org/en-US/docs/Web/API/EventListener
// https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener




























